#!/bin/bash

if [ $1 == 0 ]
then
echo "stop button"
fi

if [ $1 == 1 ]
then
echo "radio button"
fi

if [ $1 == 2 ]
then
echo "ai button"
fi

if [ $1 == 3 ]
then
echo "aux1 off"
fi

if [ $1 == 4 ]
then
echo "aux 1 on"
fi

if [ $1 == 5 ]
then
echo "aux 2 off"
fi

if [ $1 == 6 ]
then
echo "aux 2 on"
fi

if [ $1 == 7 ]
then
echo "kiss button"
fi

if [ $1 == 8 ]
then
echo "peggy button"
fi

if [ $1 == 9 ]
then
echo "city button"
fi

if [ $1 == 10 ]
then
echo "virgin button"
fi

if [ $1 == 11 ]
then
echo "power button"
fi

if [ $1 == 12 ]
then
echo "cjob button"
fi

if [ $1 == 13 ]
then
echo "tsn button"
fi

if [ $1 == 14 ]
then
echo "berlin button"
fi

if [ $1 == 15 ]
then
echo "music folder button"
fi

if [ $1 == 16 ]
then
echo "current button"
fi

if [ $1 == 17 ]
then
echo "forecast button"
fi

if [ $1 == 18 ]
then
echo "alert button"
fi

if [ $1 == 19 ]
then
echo "scifi button"
fi

if [ $1 == 20 ]
then
echo "play office button"
fi

if [ $1 == 21 ]
then
echo "horror button"
fi

if [ $1 == 22 ]
then
echo "crime button"
fi

if [ $1 == 23 ]
then
echo "randm button"
fi

if [ $1 == 24 ]
then
echo "play lr button"
fi

if [ $1 == 25 ]
then
echo "play ouside button"
fi

if [ $1 == 26 ]
then
echo "play all button"
fi

if [ $1 == 27 ]
then
echo "lr off button"
fi

if [ $1 == 28 ]
then
echo "lr on button"
fi

if [ $1 == 29 ]
then
echo "bath off button"
fi

if [ $1 == 30 ]
then
echo "bath on button"
fi

if [ $1 == 31 ]
then
echo "bt1 off button"
fi

if [ $1 == 32 ]
then
echo "br1 on button"
fi

if [ $1 == 33 ]
then
echo "br2 off button"
fi

if [ $1 == 34 ]
then
echo "br2 on button"
fi

if [ $1 == 35 ]
then
echo "office off button"
fi

if [ $1 == 36 ]
then
echo "office on button"
fi

if [ $1 == 37 ]
then
echo "misc off button"
fi

if [ $1 == 38 ]
then
echo "misc on button"
fi

if [ $1 == 39 ]
then
echo "lr off button"
fi

if [ $1 == 40 ]
then
echo "lr on button"
fi

if [ $1 == 41 ]
then
echo "bath of button"
fi

if [ $1 == 42 ]
then
echo "bath on button"
fi

if [ $1 == 43 ]
then
echo "br1 off button"
fi

if [ $1 == 44 ]
then
echo "br1 on button"
fi

if [ $1 == 45 ]
then
echo "br2 off button"
fi

if [ $1 == 46 ]
then
echo "br2 on button"
fi

if [ $1 == 47 ]
then
echo "office off button"
fi

if [ $1 == 48 ]
then
echo "office on button"
fi

if [ $1 == 49 ]
then
echo "misc off button"
fi

if [ $1 == 50 ]
then
echo "misc on button"
fi
