#!/usr/bin/perl -w
#my $MQTT2=0;
#sleep(10);
open(SUB, "/usr/bin/mosquitto_sub -h 192.168.168.150 -t /switch/SW0 |");
#my $filename = '/tmp/MQTT/grid.TMP' ;
#system("touch $filename");

#my $cnt=0;
#SUB->autoflush(1);

while ($MQTT = <SUB>) {
#$cnt++;
#if ( $MQTT < -500 ) { $MQTT = $MQTT * -1 ;}
#print " count = $cnt\n";
#open(FH, '>', $filename) or die $!;
#$MQTT2=($MQTT2+$MQTT);
#   $MQTT=($MQTT/1000);
#open(FH, '>>', $filename) or die $!;
#print FH $MQTT, " " ;
#close(FH);
#system("mosquitto_pub  -t /grid -m '$MQTT'");
print "$MQTT";
#print "cumlative = $MQTT2\n";
#if ($cnt >9){
#$MQTT2=($MQTT2/$cnt);
#$cnt=0;
#print " average = $MQTT2\n";
#if ( $MQTT2 < 20000) {
system("./process.sh $MQTT");

#system("curl -s 'http://127.0.0.1:8080/json.htm?type=command&param=udevice&idx=1&nvalue=0&svalue=$MQTT2;0' ");
#$MQTT2=0;
#}
#}

#system("curl -s 'http://127.0.0.1:8080/json.htm?type=command&param=udevice&idx=1&nvalue=0&svalue=$MQTT;0' ");


}
