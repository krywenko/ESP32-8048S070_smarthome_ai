for output 
interface.pl  and process.sh are for the screen  switch   interface.  monitors the  mqtt/SW0 for changes and then passes it to process.sh  to trigger events --add in you functions here

for inputs 
there are  4  mqtt topics it monitors  
weewx/ 
/energy/
/input/
and /ai

mqtt_WEMOS_mini_ESP_2Way_com_AI_monitor  is an ino sketch for  an esp wemos mini - for some reason my esp32 wireless was not very stable . so i bypassed it  using a hardware uart on thes screen using P4 ( and the cable that came with the screen) it is rx/tx and power supply for the esp  the sketch is my standard serial program i use so it has alot of extra input monitoring 
